---
remediation_report: true
remediator_model: claude-opus-5
remediated_at: 2026-08-04T13:55:00Z
target_doc: ast-reference/values.md
review_report: ../../reviews/ast-reference/values.md.review.md
target_doc_source_commit_before: 53b76e6d3009b8e6434d41573524c7ce5c499d23
target_doc_source_commit_after: 53b76e6d3009b8e6434d41573524c7ce5c499d23
actions:
  fixed: 5
  rejected_bogus: 0
  rejected_out_of_scope: 0
  deferred: 1
  escalated: 0
---

# Remediation report for ast-reference/values.md

## Summary

Five of six findings were fixed and one was deferred. The critical
hash-consing finding was real: the universal pointer-identity guarantee
is now scoped to values built through `ASTBuilder::getOrCreate`, with
the `DifferentiateVal` substitution path named as the exception. The
`ModifierVal` storage claim, the `DifferentiateVal` data-shape claim,
the stale "outside this page's watched paths" text for
`TypeEqualityWitness`, and the missing pipeline cross-reference were
each corrected in place. F-004 (nine `## Nodes` sub-tables instead of
one) is a genuine contract deviation but needs a whole-section
restructure shared with `modifiers.md`, so it is deferred.

## Actions

| Finding ID | Action | Rationale | Fix summary |
| --- | --- | --- | --- |
| F-001 | fixed | Verified at HEAD: `source/slang/slang-ast-val.cpp:3278` builds the substituted `DifferentiateVal` with `createByNodeType`, and `source/slang/slang-ast-builder.cpp:446-450` shows that entry point only calls `SyntaxClass::createInstance`, never the `getOrCreate` cache. The universal guarantee was therefore false. Neither file is in this page's `watched_paths`, so the new prose names the functions without citing their line numbers. | `## Source`: guarantee scoped to values built through `ASTBuilder::getOrCreate`; `### Hash-consing and the ASTBuilder`: "Every"/"every" softened to "Almost every" and a sentence added naming `DifferentiateVal::_substituteImplOverride` as the exception |
| F-002 | fixed | Confirmed: `source/slang/slang-ast-expr.h:947` declares `ModifiedTypeExpr::modifiers` as syntax-level `Modifiers`, and `source/slang/slang-check-expr.cpp:9266,9306,9311` builds a separate `List<Val*> modifierVals` and passes it to `getModifiedType`, so the expression never stores `ModifierVal`s. | `### Modifier values`: storage attributed to `ModifiedType` alone, with checking a `ModifiedTypeExpr` described as the producer that converts its syntax modifiers into these values |
| F-003 | fixed | Confirmed: `source/slang/slang-ast-val.h:1220-1282` gives the base a single `getFunc()` operand and the five subclasses add no state, so "pairs a differentiation direction with the `DeclRef`" misdescribed both the data shape and the artifact subclasses. | `### Differentiation values`: first sentence now says each node stores only the function decl-ref and that the subclass selects a mode or a backward-derivative artifact; trailing surface-syntax parenthetical promoted to its own sentence |
| F-004 | deferred | Correct against `docs/generated/design/_meta/prompts/_common.md:99` ("a single table"), and the page is an outlier: `declarations.md`, `expressions.md`, `statements.md`, and `types.md` each use one table. The fix is not a one-row edit — it must relocate five interstitial `###` prose paragraphs (two of them just rewritten under F-002 and F-003) into `## Notable nodes` and drops those sub-headings as anchor targets. `modifiers.md` has 26 such sub-tables, so the family-wide convention should be settled in one pass. Follow-up: regenerate `## Nodes` for `values.md` and `modifiers.md` together, or state the sub-table allowance in the family contract. | — |
| F-005 | fixed | The document-text half is correct and was fixed: `regenerate.py show ast-reference/values.md` resolves four files including both checker sources, so the "outside this page's watched paths" claim was stale. The front-matter `watched_paths_digest` half is out of scope here — `docs/generated/design/_meta/prompts/_remediate.md:97-100` reserves that field for the operator's `mark-fresh` run. | `### TypeEqualityWitness`: stale "adding these paths would let this callout cite them" text replaced with direct citations to `SemanticsVisitor::createTypeEqualityWitness` (`slang-check-conformance.cpp:531`) and its callers at `slang-check-inheritance.cpp:699,2024,2084` |
| F-006 | fixed | Confirmed: `docs/generated/design/_meta/prompts/_common.md:119-122` requires the relevant `pipeline/` page, and the list had none. `pipeline/03-semantic-check.md` is a manifest key (`manifest.yaml:131`) and is the stage that constructs these values. | `## See also`: added a `../pipeline/03-semantic-check.md` bullet naming conformance checking and constant folding as the producers |
